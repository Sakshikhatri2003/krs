﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using WebApp.admin;

namespace Navygen1.admin
{
    public partial class News : System.Web.UI.Page
    {
        string cs = ConfigurationManager.ConnectionStrings["Typing"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {



            SqlConnection con = new SqlConnection(cs);
            string query = "Select * from News";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            gvsavedata.DataSource = cmd.ExecuteReader();
            gvsavedata.DataBind();
            con.Close();

            try
            {
                if (Request.QueryString["NewsID"].Length > 0)
                {
                    int nid = Convert.ToInt32( Request.QueryString["NewsID"].ToString());


                    string Newsquery = "Select * from News where NewsID='"+@nid+"'";
                    SqlCommand cmd1 = new SqlCommand(Newsquery, con);
                    

                    con.Open();
                    SqlDataReader dr = cmd1.ExecuteReader();
                    if (dr.Read())
                    {
                        Titles.Text = dr.GetValue(dr.GetOrdinal("Title")).ToString();
                        NewsType.Text = dr.GetValue(dr.GetOrdinal("NewsType")).ToString();
                       
                        Descripation.Text=dr.GetValue(dr.GetOrdinal("Descripation")).ToString() ;
                        String datestring = dr.GetValue(dr.GetOrdinal("NewsDate")).ToString();
                       
                        DateTime dt = DateTime.ParseExact(datestring, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                        NewsDate.Text=dt.ToString();
                    }
                    con.Close();

                }

            }
            catch { }
           


        }
    
        

        protected void save_Click(object sender, EventArgs e)
        {

            try
            {
                int nid = 0;
                
                if (Request.QueryString["NewsID"] != null)
                {

                    nid = Convert.ToInt32(Request.QueryString["NewsID"].ToString());

                    SqlConnection con = new SqlConnection(cs);

                    string query = "Update News set Title=@Title,NewsType=@NewsType,Descripation=@Descripation,NewsDate=@NewsDate where NewsID='" + @nid + "'";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@Title", Titles.Text);
                    cmd.Parameters.AddWithValue("@NewsType", NewsType.Text);
                    cmd.Parameters.AddWithValue("@Descripation", Descripation.Text);
                    cmd.Parameters.AddWithValue("@NewsDate", NewsDate.Text);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    Titles.Text = NewsType.Text = Descripation.Text = NewsDate.Text = "";
                    lbl.Text = "<div class='alert alert-success'><strong>Success!</strong> Your request Successfully Submited.</div>";



                }
                else
                {
                    SqlConnection con = new SqlConnection(cs);
                    string query = "insert into News(Title, NewsType, Descripation,NewsDate)values(@Title, @NewsType, @Descripation, @NewsDate)";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@Title", Titles.Text);
                    cmd.Parameters.AddWithValue("@NewsType", NewsType.Text);
                    cmd.Parameters.AddWithValue("@Descripation", Descripation.Text);
                    cmd.Parameters.AddWithValue("@NewsDate", NewsDate.Text);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    Titles.Text = NewsType.Text = Descripation.Text = NewsDate.Text = "";
                    lbl.Text = "<div class='alert alert-success'><strong>Success!</strong> Your request Successfully Submited.</div>";
                    Response.Redirect("News.aspx");



                    
                }
            }
            catch (Exception ex)
            {
                lbl.Text = "<div class='alert alert-danger'><strong>Error!</strong> " + ex.Message + ".</div>";
            }
        }


    }
}
