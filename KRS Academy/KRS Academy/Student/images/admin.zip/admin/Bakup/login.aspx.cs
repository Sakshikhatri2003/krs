﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Navygen1.admin
{
    public partial class login : System.Web.UI.Page
    {
        string cs = ConfigurationManager.ConnectionStrings["Typing"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {


        }

        

        protected void login_Click1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            String query = " select * from loginMaster where UserName=@user and Password=@pass";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@user", Email.Text.ToString());
            cmd.Parameters.AddWithValue("@pass", Password.Text.ToString());
            SqlDataReader sdr = cmd.ExecuteReader();


            if (sdr.Read())
            {
                sdr.Close();
                cmd.Dispose();
                con.Close();
                Response.Redirect("adminpage.aspx");


            }

            else
            {
                sdr.Close();
                cmd.Dispose();
                con.Close();
                
                lbl.Text = "Password and Name Not Found";


            }


            Email.Text = "";
            Password.Text = "";
        }
    }
}