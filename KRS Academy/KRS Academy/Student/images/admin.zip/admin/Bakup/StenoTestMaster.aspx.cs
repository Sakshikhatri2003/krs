﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Navygen1.admin
{
    public partial class StenoTestMaster : System.Web.UI.Page
    {
        string cs = ConfigurationManager.ConnectionStrings["Typing"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
            string query = "Select * from StenoTestMaster";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            gvsavedata.DataSource = cmd.ExecuteReader();
            gvsavedata.DataBind();
            con.Close();

            try
            {
                if (Request.QueryString["StenoTestID"].Length > 0)
                {
                    int nid = Convert.ToInt32(Request.QueryString["StenoTestID"].ToString());


                    string Newsquery = "Select * from StenoTestMaster where StenoTestID='" + @nid + "'";
                    SqlCommand cmd1 = new SqlCommand(Newsquery, con);


                    con.Open();
                    SqlDataReader dr = cmd1.ExecuteReader();
                    if (dr.Read())
                    {
                        TestName.Text = dr.GetValue(dr.GetOrdinal("TestName")).ToString();
                        Languages.Text = dr.GetValue(dr.GetOrdinal("Languages")).ToString();
                        Words.Text = dr.GetValue(dr.GetOrdinal("Words")).ToString();
                        Paragraph.Text = dr.GetValue(dr.GetOrdinal("Paragraph")).ToString();
                        Speed.Text = dr.GetValue(dr.GetOrdinal("Speed")).ToString();

                    }
                    con.Close();

                }

            }
            catch { }

        }

        protected void save_Click(object sender, EventArgs e)
        {
            try
            {
                string path = Path.GetFileName(FilePath.FileName);
                path = path.Replace(" ", "");

                SqlConnection con = new SqlConnection(cs);
                string query = "insert into StenoTestMaster(TestName, Languages, Words,Paragraph,Duration,Speed,FilePath)values(@TestName, @Languages, @Words, @Paragraph,@Duration,@Speed,@FilePath)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@TestName", TestName.Text);
                cmd.Parameters.AddWithValue("@Languages", Languages.Text);
                cmd.Parameters.AddWithValue("@Words", Words.Text);
                cmd.Parameters.AddWithValue("@Paragraph", Paragraph.Text);
                cmd.Parameters.AddWithValue("@Duration", Duration.Text);
                cmd.Parameters.AddWithValue("@Speed", Speed.Text);
                cmd.Parameters.AddWithValue("@FilePath", path);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                TestName.Text = Languages.Text = Words.Text = Paragraph.Text = Duration.Text = Speed.Text= "";
                lbl.Text = "<div class='alert alert-success'><strong>Success!</strong> Your request Successfully Submited.</div>";
                Response.Redirect("TypingTestMaster.aspx");


            }
            catch (Exception ex)
            {
                lbl.Text = "<div class='alert alert-danger'><strong>Error!</strong> " + ex.Message + ".</div>";
            }
        }
    }
}