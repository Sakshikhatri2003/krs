﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Navygen1.admin
{
    public partial class TypingTestMaster : System.Web.UI.Page
    {
        string cs = ConfigurationManager.ConnectionStrings["Typing"].ConnectionString;


        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
            string query = "Select * from TypingTestMaster";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            gvsavedata.DataSource = cmd.ExecuteReader();
            gvsavedata.DataBind();
            con.Close();

            try
            {
                if (Request.QueryString["TypingTestID"].Length > 0)
                {
                    int nid = Convert.ToInt32(Request.QueryString["TypingTestID"].ToString());


                    string Newsquery = "Select * from TypingTestMaster where TypingTestID='" + @nid + "'";
                    SqlCommand cmd1 = new SqlCommand(Newsquery, con);


                    con.Open();
                    SqlDataReader dr = cmd1.ExecuteReader();
                    if (dr.Read())
                    {
                        TestName.Text = dr.GetValue(dr.GetOrdinal("TestName")).ToString();
                        Languages.Text = dr.GetValue(dr.GetOrdinal("Languages")).ToString();
                        Words.Text = dr.GetValue(dr.GetOrdinal("Words")).ToString();
                        Paragraph.Text = dr.GetValue(dr.GetOrdinal("Paragraph")).ToString();

                    }
                    con.Close();

                }

            }
            catch { }



        

        }

        protected void save_Click(object sender, EventArgs e)
        {
            try
            {
               
                    SqlConnection con = new SqlConnection(cs);
                    string query = "insert into TypingTestMaster(TestName, Languages, Words,Paragraph,Times)values(@TestName, @Languages, @Words, @Paragraph,@Times)";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@TestName", TestName.Text);
                    cmd.Parameters.AddWithValue("@Languages", Languages.Text);
                    cmd.Parameters.AddWithValue("@Words", Words.Text);
                    cmd.Parameters.AddWithValue("@Paragraph", Paragraph.Text);
                    cmd.Parameters.AddWithValue("@Times", Times.Text);

                con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    TestName.Text = Languages.Text = Words.Text = Paragraph.Text = Times.Text = "";
                    lbl.Text = "<div class='alert alert-success'><strong>Success!</strong> Your request Successfully Submited.</div>";
                    Response.Redirect("TypingTestMaster.aspx");

                
            }
            catch (Exception ex)
            {
                lbl.Text = "<div class='alert alert-danger'><strong>Error!</strong> " + ex.Message + ".</div>";
            }
        }
    }
}